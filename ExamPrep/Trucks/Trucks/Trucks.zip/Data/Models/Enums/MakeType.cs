﻿namespace Trucks.Data.Models.Enums
{
    public enum MakeType
    {
        Daf = 0,
        Man,
        Mercedes,
        Scania,
        Volvo
    }
}