﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=WDESK\SQLEXPRESS;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
