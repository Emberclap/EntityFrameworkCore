﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=WDESK\SQLEXPRESS;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
