﻿namespace Trucks.Data.Models.Enums
{
    public enum CategoryType
    {
        Flatbed = 0,
        Jumbo,
        Refrigerated,
        Semi
    }
}