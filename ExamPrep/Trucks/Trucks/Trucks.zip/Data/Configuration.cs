﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=WDESK\SQLEXPRESS;Database=Trucks;Integrated Security=True;Encrypt=False";
    }
}