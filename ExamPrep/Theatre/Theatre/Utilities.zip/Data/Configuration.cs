﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=WDESK\SQLEXPRESS;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}
